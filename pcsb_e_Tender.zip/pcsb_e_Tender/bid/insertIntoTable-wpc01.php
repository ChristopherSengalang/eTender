User
<?php
if (isset($_POST['bid-submit'])) {
    require 'includes/dbh.inc.php';

    $tenderId = $_POST['TenderID'];
    $orgId = $_POST['OrgID'];
    

    // Use prepared statement to prevent SQL injection
    $sql = "INSERT INTO bids (TenderID, OrgID) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $tenderId, $orgId);
    $stmt->execute();

    // Check for errors
    if (!$stmt) {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    } else {
        echo "<script type='text/javascript'>alert('START BIDDING');
        window.location.href='submit-form-wpc01.php';
        </script>";
    }
} else {
    header('location: tender.php');
    exit();
}
?> "