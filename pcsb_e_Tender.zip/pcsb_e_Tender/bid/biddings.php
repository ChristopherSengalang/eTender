<?php
include"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:login");
}

?>

<?php include"sidebar.php"?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <link rel="icon" type="image/png"  sizes="16x16" href="adminlte/img/logo.png">

     

    <title>PCSB e-Tender Management System</title>
    
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    

    <link href="css/lib/calendar2/semantic.ui.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/popup_style.css">
    
    
    
</head>

<body class="fix-header fix-sidebar">
    
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    
    <div id="main-wrapper">
        
        <div class="header">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.php">         
                <span><img src="adminlte/img/logo.png" style="height:65px; width: auto" alt="homepage" class="dark-logo" /></span>   
                    </a>
                </div>               
                <div class="navbar-collapse">                  
                    <ul class="navbar-nav mr-auto mt-md-0">                       
                        <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted  " href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                        <li class="nav-item m-l-10"> <a class="nav-link sidebartoggler hidden-sm-down text-muted  " href="javascript:void(0)"><i class="ti-menu"></i></a> </li>                      
                    </ul>         
                    <ul class="navbar-nav my-lg-0">       
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           <img src="./img/sp.jpg" width="40px" height="40px">                                                           
                            </a>
                            <div class="dropdown-menu dropdown-menu-right animated zoomIn">
                                <ul class="dropdown-user">                                                               
                                <li><a href="includes/logout.inc.php">Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</body>
</html>
        



        
        <div class="page-wrapper">
            
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-bold">PCSB e-Tender Management System</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">i - Bidding</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
            
            
            <div class="container-fluid">
                  <div class="row">
                    <div class="col-lg-12">
                
                  <div class="card card-outline-primary">
                       <div class="card-body">
                       <?php
//print_r($_SESSION);
?>
                  <form class="user"  method="post">
                    <div class="form-group">
					Company ID
                      <input type="text" class="form-control form-control-user" readonly value="<?=$_SESSION['name']?>" name="name" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Your Name...">
                    </div>
                    <div class="form-group">
					Company Name
                      <input type="text" class="form-control form-control-user" readonly value="<?=$_SESSION['mobile']?>" name="name" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Your Name...">
                    </div>
					<div class="form-group">
					Company Email-
                      <input type="text" class="form-control form-control-user" readonly name="email" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Your Email..." value=<?=$_SESSION['email']?>>
                    </div>                    
					<div class="form-group">
					Tender ID-
                      <input type="text" class="form-control form-control-user" name="description" id="exampleInputPassword" placeholder="Tender ID" value="" required>
                    </div>
                    
                     <input type="submit"  value="BIDDING" name="bidding" class="btn btn-primary btn-user btn-block">
               
                    <hr>
                    
                  </form>
				  
				  <?php
if(isset($_REQUEST['bidding']))
	{
		extract($_REQUEST);
	//$email=trim($_REQUEST['email']);
	//$password=trim($_REQUEST['password']);
	
	$userid=$_SESSION['id'];
	
	echo $query="INSERT INTO `bidding`( `name`, `email`, `mobile`, `charge`, `qty`, `tenderid`, `userid`,`description`) VALUES 
	( '$name', '$email', '$mobile', '$charge', '$qty', '$id','$userid','$description')";
	
	
	
	$n=iud($query);
	//$n=mysqli_num_rows($login_data);
	if($n==1)
	{
			
		 echo'<script>alert("BIDDING SUCCESSFUL");
window.location="tender"		 </script>';
	}
	else
	{
		echo"Something Wrong Try Again";
	}
	}
		
	
			  
			  
			  ?>
                            </div>
                            </div>
                    </div>
                </div>
                </div>
                
            </div>
            

<?php include"footer.php"?>


