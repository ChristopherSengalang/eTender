


<?php include"header.php"?>
<?php include"sidebar.php"?>
        
        <div class="page-wrapper">
            
            <div class="row page-titles">
                <div class="col-md-7 align-self-center">
                    <h3 class="text-primary">Checklist For Tender Documents and Mandatory Supporting Documents</h3> </div>
                <div class="col-md-5 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
                        <li class="breadcrumb-item active">ii - Submit Form</li>
                    </ol>
                </div>
            </div>
            
            
            <div class="container-fluid">
                
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card card-outline-primary">
                        <marquee scrollamount=4><b> Please submit your required documents to finalized the tender process.</i></b></marquee>  
                            <div class="card-body">
                            <br>
                            <br>
                            <form action="process.php" method="post" id="post-form" enctype="multipart/form-data">
                                <input type="hidden" name="id" value="<?= isset($id) ? $id : 0  ?>">
                                <input type="hidden" name="auto_id" value="<?= isset($auto_id) ? $auto_id : "" ?>">

                                <div class="form-body">
                                    <div>
                                        <br>
                                        <h3 class="card-title m-t-15">Form of Tender</h3>
                                        <hr>
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File"  style="color:red;">* Tenderer must fill, sign (Authorised Signatory) & Company Stamp the document.</label>
                                                    <input type="file" name="files[]" id="file1" accept=".pdf" class="form-control" required>
                                                    </div>
                                            </div>                                                                                     
                                        </div>   
                                        <h3 class="card-title m-t-15">Tender Price</h3>
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File"  style="color:red;">* Please ensure tender price tally with the form of tender</label>
                                                    <input type="file" name="files[]" id="file2" accept=".txt" class="form-control" required>
                                                </div>
                                            </div>                                                                                     
                                        </div>     


                                        </div>

                                        </div>
                                        <div class="form-actions">
                                        <button type="submit" class="btn btn-success" name="submit" id="btnSubmit"> <i class="fa fa-check"></i> Confirm</button>
                                            <a href="tender.php"><button type="button" class="btn btn-inverse">Cancel</button></a>
                                        </div>
                            </form>
                        </div>
                    </div>
                
                            </div>
                            </div>
                            </div>
                            <div class="popup popup--icon -error js_error-popup" id="show_error">
                            <div class="popup__background"></div>
                            <div class="popup__content">
                                <h3 class="popup__content__title">
                                Error 
                                </h1>
                                <p>Password and Confirm Password do no match</p>
                                <p>
                                
                                <button class="button button--error" data-for="js_error-popup">Close</button>
                                
                                </p>
                            </div>
                            </div>
                   

<?php include"footer.php"?>


          


     <script type="text/javascript">
    $(function () {
        $("#btnSubmit").click(function () {
            var password = $("#txtPassword").val();
            var confirmPassword = $("#txtConfirmPassword").val();
            if (password != confirmPassword) {

                 $('#show_error').addClass('popup--visible');
                return false;
            }
            else{
            return true;
        }
        });
    });




    var addButtonTrigger = function addButtonTrigger(el) {
el.addEventListener('click', function () {
var popupEl = document.querySelector('.' + el.dataset.for);
popupEl.classList.toggle('popup--visible');
});
};

Array.from(document.querySelectorAll('button[data-for]')).
forEach(addButtonTrigger);
</script>