<?php
if (isset($_POST['bid-submit'])) {
    require 'includes/dbh.inc.php';

    $tenderId = $_POST['TenderID'];
    $orgId = $_POST['OrgID'];

    // Use prepared statement to prevent SQL injection
    $sql = "INSERT INTO bids (TenderID, OrgID) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $tenderId, $orgId);
    $stmt->execute();

    // Check for errors
    if (!$stmt) {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    } else {
        // Redirect based on TenderID
        switch ($tenderId) {
            case 1:
                header('location: submit-form-1.php');
                exit();
                break;
            case 2:
                header('location: page2.php');
                exit();
                break;
            case 3:
                header('location: page3.php');
                exit();
                break;
            // Add more cases as needed

            default:
                // If TenderID doesn't match any specific case, redirect to the default page
                header('location: submit-form.php');
                exit();
        }
    }
} else {
    header('location: biddings.php');
    exit();
}
?>
