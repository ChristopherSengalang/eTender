<?php
session_start();
if (!isset($_SESSION['userId'])) {
    header('location: login.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $tenderID = $_POST['tenderID'];
    $newDueDate = $_POST['newDueDate'];

    // Update the record in the database
    require 'includes/dbh.inc.php';
    $sql = "UPDATE tender SET DueDate = '$newDueDate' WHERE TenderID = '$tenderID'";
    mysqli_query($conn, $sql);

    header('location: viewbiddings.php'); // Redirect to the dashboard after updating
} else {
    header('location: edit_tender.php'); // Redirect to the dashboard if the form is not submitted
}
?>
