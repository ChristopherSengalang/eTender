


<?php include"header.php"?>
<?php include"sidebar.php"?>

<?php 
    require_once('config.php');
    if(isset($_GET['auto_id']) || isset($_GET['id'])){
        $_id = isset($_GET['auto_id']) ? $_GET['auto_id'] : (isset($_GET['id']) ? $_GET['id'] : "");
        if(!empty($_id)){
            $sql = "SELECT * FROM `posts` where `id` = '{$_id}'";
            $get = $conn->query($sql);
            if($get->num_rows > 0){
                $result = $get->fetch_assoc();
                $id = $result['id'];
                $title = stripslashes($result['title']);
                $content = stripslashes($result['content']);
                $status = $result['status'];
                if($result['status'] == 'draft'){
                    $id = $result['parent_id'] > 0 ? $result['parent_id'] : "";
                    $auto_id = $result['id'] > 0 ? $result['id'] : "";
                }
            }
        }
    }
    if(isset($id) && !isset($auto_id) && isset($status) && $status == 'publish'){
        $check_draft_sql = "SELECT id FROM `bids` where `status` = 'draft' and `parent_id` = '{$id}' order by abs(unix_timestamp(`created_at`)) desc limit 1";
        $check_draft = $conn->query($check_draft_sql);
        if($check_draft->num_rows > 0){
            $draft_available_id = $check_draft->fetch_assoc()['id'];
        }
    }
    ?>
        
        <div class="page-wrapper">
            
            <div class="row page-titles">
                <div class="col-md-7 align-self-center">
                    <h3 class="text-primary">Checklist For Tender Documents and Mandatory Supporting Documents</h3> </div>
                <div class="col-md-5 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
                        <li class="breadcrumb-item active">ii - Submit Form</li>
                    </ol>
                </div>
            </div>
            
            
            <div class="container-fluid">
                
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card card-outline-primary">
                        <marquee scrollamount=4><b> Please submit your required documents to finalized the tender process.</i></b></marquee>  
                            <div class="card-body">
                            <br>
                            <br>
                            <form action="process.php" method="post" id="post-form" enctype="multipart/form-data">
                                <input type="hidden" name="id" value="<?= isset($id) ? $id : 0  ?>">
                                <input type="hidden" name="auto_id" value="<?= isset($auto_id) ? $auto_id : "" ?>">

                                <div class="form-body">
                                    <div>
                                        <br>
                                        <h3 class="card-title m-t-15">Form of Tender</h3>
                                        <hr>
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File"  style="color:red;">* Tenderer must fill, sign (Authorised Signatory) & Company Stamp the document.</label>
                                                    <input type="file" name="files[]" id="file1" accept=".pdf" class="form-control" required>
                                                    </div>
                                            </div>                                                                                     
                                        </div>   
                                        <h3 class="card-title m-t-15">Tender Price</h3>
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File"  style="color:red;">* Please ensure tender price tally with the form of tender</label>
                                                    <input type="text" name="files[]" id="file2" class="form-control" required>
                                                </div>
                                            </div>                                                                                     
                                        </div>     
                                        <h3 class="card-title m-t-15">Declaration of Bona Fide Competitive Tender</h3>                            
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File" style="color:red;">* The Tenderer must fill, sign (Authorised Signatory) & Company Stamp the document.</label>
                                                    <input type="file" name="files[]" id="file3" accept=".pdf" class="form-control" required>
                                                    </div>
                                            </div>                                                                                       
                                        </div>     
                                        <h3 class="card-title m-t-15">Form A - Surat Perakuan Kebenaran Maklumat dan Pengesahan Dokumen Yang Dikemukakan oleh Petender</h3>                                                                    
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File"  style="color:red;">* The Tenderer must fill, sign Authorised Signatory (Including Authorisation Letter by Bidder) & Company Stamp the document</label>
                                                    <input type="file" name="files[]" id="file4" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div>  
                                        <h3 class="card-title m-t-15">Form B - Tenderer's Particulars</h3> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Form 24 (List of Name of Shareholders and their Corresponding Equity)</label>
                                                    <input type="file" name="files[]" id="file5" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div> 
                                        <h3 class="card-title m-t-15">Form C - Financial Information</h3> 
                                        <label class="control-label col-sm-12" for="File"  style="color:red;">* The tenderer must submit certified bank statement</label>
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Bank Statement November 2023</label>
                                                    <input type="file" name="files[]" id="file6" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Bank Statement December 2023</label>
                                                    <input type="file" name="files[]" id="file7" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Bank Statement January 2024</label>
                                                    <input type="file" name="files[]" id="file8" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Audited Company Account - Form C1 Banker's Report of Facilities</label>
                                                    <input type="file" name="files[]" id="file9" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div> 
                                        <h3 class="card-title m-t-15">Form D - List of Contractor's Experience Record (For the Past 3 Years)</h3> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Copy of Letter Of Acceptance(LOA) for each Project</label>
                                                    <input type="file" name="files[]" id="file10" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div>
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Copy of Certificate of Practical Completion (CPC) for each project</label>
                                                    <input type="file" name="files[]" id="file11" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div>
                                        <h3 class="card-title m-t-15">Form E - List of Ongoing Contract</h3> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Copy of Letter of Acceptance (LOA) for each project</label>
                                                    <input type="file" name="files[]" id="file12" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div>
                                        <h3 class="card-title m-t-15">Form F - List of Plants/ Machinery and Equipment</h3> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Copy of Registration Card (Front & Back)</label>
                                                    <input type="file" name="files[]" id="file13" accept=".pdf" class="form-control" >
                                                </div>
                                            </div>                                          
                                        </div>
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Receipt of Proof of Purchase</label>
                                                    <input type="file" name="files[]" id="file14" accept=".pdf" class="form-control" >
                                                </div>
                                            </div>                                          
                                        </div>
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Copy of Leasing & Rental Agreement</label>
                                                    <input type="file" name="files[]" id="file15" accept=".pdf" class="form-control" >
                                                </div>
                                            </div>                                          
                                        </div>
                                        <h3 class="card-title m-t-15">Form G - List of Technical Staff</h3> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Copy of latest EPF Statement (KWSP A)</label>
                                                    <input type="file" name="files[]" id="file16" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div>
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Relevant copies of Professional Service Agreement (for staff under contract basis)</label>
                                                    <input type="file" name="files[]" id="file17" accept=".pdf" class="form-control" >
                                                </div>
                                            </div>                                          
                                        </div>
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Copy of Qualification/ academic/ professional certificate of each technical staff</label>
                                                    <input type="file" name="files[]" id="file18" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div>
                                        <h3 class="card-title m-t-15">Grand Summary</h3> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="file" name="files[]" id="file19" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div>
                                        <h3 class="card-title m-t-15"> Bills of Approximate Quantities </h3> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                            <label style="color:red;">*Compress in ZIP file</label>
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Section A</label>
                                                    <input type="file" name="files[]" id="file20" accept=".pdf" class="form-control" required>

                                                    <label class="control-label col-sm-12" for="File">Section B</label>
                                                    <input type="file" name="files[]" id="file21" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div>
                                        <h3 class="card-title m-t-15">Schedule of Daywork Rates</h3> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="file" name="files[]" id="file22" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div>
                                        <h3 class="card-title m-t-15">Summary of Tender for Mechanical and Electrical Services</h3> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">1. Summary of Tender for Mechanical and Electrical Services</label>
                                                    <input type="file" name="files[]" id="file23" accept=".pdf" class="form-control" required>
                                                    <label class="control-label col-sm-12" for="File">2. Bill of Approximate Quantities for Mechanical Services</label>
                                                    <input type="file" name="files[]" id="file24" accept=".pdf" class="form-control" required>
                                                    <label class="control-label col-sm-12" for="File">3. Bill of Approximate Quantities for Electrical Services</label>
                                                    <input type="file" name="files[]" id="file25" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div>
                                        <h3 class="card-title m-t-15">Schedule of Technical Data</h3> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                <label class="control-label col-sm-12" for="File">1. Electrical and Extra Low Voltage Services</label>
                                                    <input type="file" name="files[]" id="file26" accept=".pdf" class="form-control" required>
                                                    <label class="control-label col-sm-12" for="File">2. Mechanical Services</label>
                                                    <input type="file" name="files[]" id="file27" accept=".pdf" class="form-control" required>
                                                    <label class="control-label col-sm-12" for="File">3. HT/LT Services</label>
                                                    <input type="file" name="files[]" id="file28" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                          
                                        </div>
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-12" for="File">Company Profile</label>
                                                    <input type="file" name="files[]" id="file29" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                                                                     
                                        </div> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                <label class="control-label col-sm-12" for="File">Others supporting documents</label>
                                                    <input type="file" name="files[]" id="file30" accept=".pdf" class="form-control" required>
                                                </div>
                                            </div>                                                                                     
                                        </div> 
                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="checkbox" name="love" value="love" id="love"><label for="love" required> 
                                                    &nbsp; I hereby certify that the information/data provided herein is accurate, and acknowledge that any inaccuracies may result in disqualification from the tender process.
                                                    </label>
                                                </div>
                                            </div>                                          
                                        </div>

                                        </div>

                                        </div>
                                        <div class="form-actions">
                                        <button type="submit" class="btn btn-success" name="submit" id="btnSubmit"> <i class="fa fa-check"></i> Confirm</button>
                                            <a href="tender.php"><button type="button" class="btn btn-inverse">Cancel</button></a>
                                        </div>
                            </form>
                        </div>
                    </div>
                
                            </div>
                            </div>
                            </div>
                            <div class="popup popup--icon -error js_error-popup" id="show_error">
                            <div class="popup__background"></div>
                            <div class="popup__content">
                                <h3 class="popup__content__title">
                                Error 
                                </h1>
                                <p>Password and Confirm Password do no match</p>
                                <p>
                                
                                <button class="button button--error" data-for="js_error-popup">Close</button>
                                
                                </p>
                            </div>
                            </div>
                   

<?php include"footer.php"?>


          


     <script type="text/javascript">
    $(function () {
        $("#btnSubmit").click(function () {
            var password = $("#txtPassword").val();
            var confirmPassword = $("#txtConfirmPassword").val();
            if (password != confirmPassword) {

                 $('#show_error').addClass('popup--visible');
                return false;
            }
            else{
            return true;
        }
        });
    });




    var addButtonTrigger = function addButtonTrigger(el) {
el.addEventListener('click', function () {
var popupEl = document.querySelector('.' + el.dataset.for);
popupEl.classList.toggle('popup--visible');
});
};

Array.from(document.querySelectorAll('button[data-for]')).
forEach(addButtonTrigger);
</script>