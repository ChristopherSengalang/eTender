<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $checkCompanyID = $_POST["checkCompanyID"];

    // Database connection (assuming XAMPP with default settings)
    $conn = new mysqli("localhost", "root", "", "tms");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query to retrieve company name and email based on companyID
    $sql = "SELECT OrgName, OrgEmail FROM organization WHERE OrgID = '$checkCompanyID'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data
        $row = $result->fetch_assoc();
        $OrgName = $row["OrgName"];
        $OrgEmail = $row["OrgEmail"];
        echo json_encode(array("OrgName" => $OrgName, "OrgEmail" => $OrgEmail));
    } else {
        echo json_encode(array("error" => "Company not found"));
    }

    // Close the database connection
    $conn->close();
}
?>
