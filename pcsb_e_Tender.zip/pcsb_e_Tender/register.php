
<?php
include"dbconfig.php";

?>
<!DOCTYPE html>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Register</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">

    <style>
    body {
        margin: 0;
        padding: 0;
        height: 100%;
        background: none;
        font-family: 'Montserrat', sans-serif;
    }

    .background-image {
        background-image: url('engineering_background.jpg');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .bg-primary {
        background: none;
    }

    .card {
        border-radius: 15px;
        overflow: hidden;
    }

    .card-body {
        border-radius: 15px;
    }

    .form-control {
        border-radius: 10px;
    }

    .btn-primary {
        background-color: #4e73df;
        border-color: #4e73df;
        color: #fff;
    }

    .btn-primary:hover {
        background-color: #2e59d9;
        border-color: #2e59d9;
    }

    .footer {
        background-color: #f8f9fa;
        font-size: 14px;
    }
    </style>

</head>

<body class="" style="background-image: url('./adminlte/img/Picture1.png');">
    <div class="background-image">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-8 col-sm-10">
                    <div class="card o-hidden border-0 shadow-lg my-5">
                        <div class="card-body p-0">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="p-5">
                                        <!-- Logo Section -->
                                        <div class="text-center">
                                            <img src="./adminlte/img/logo2.png" style="width: 100px;height: 100px;" alt="Your Company Logo" class="img-fluid mb-4">
                                            <h1 class="h4 text-gray-900 mb-4">REGISTER</h1>
                                        </div>
                                        <!-- End Logo Section -->
                                        <form class="user"  method="post">
                                            <div class="form-group">
                                                <input type="text" class="form-control form-control-user" name="name" id="exampleInputPassword" placeholder="Company ID">
                                                </div>
                                                <div class="form-group">
                                                <input type="text" class="form-control form-control-user" name="mobile" id="exampleInputPassword" placeholder="Company Name">
                                                </div>
                                                <div class="form-group">
                                                <input type="email" class="form-control form-control-user" name="email" id="exampleInputEmail" aria-describedby="Company Email" placeholder="Enter Email Address...">
                                                </div>
                                                <div class="form-group">
                                                <input type="password" class="form-control form-control-user" name="password" id="exampleInputPassword" placeholder="Password">
                                                </div>
                                                
                                                <div class="form-group">
                                                <input type="submit"  value="register" name="register" class="btn btn-primary btn-user btn-block">    
                                                </div>                        
                                                <hr>
                                                <div class="text-center">
                                                    <a class="small" href="login">Login Here.</a>
                                                </div>
                                            </div>
                                            </form>
                                            <?php
                            if(isset($_REQUEST['register']))
                            {
                                extract($_REQUEST);
                            $name=$_REQUEST['name'];
                                echo $query="insert into registration (`name`, `mobile`, `email`, `password`) values ('$name','$mobile','$email','$password')";
                                $n=iud($query);
                                if($n==1)
                                {
                                    echo'<script>alert("successful");
                                    window.location="login.php";</script>';
                                }
                            }

                            ?>

                                        <hr>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

            <!-- Footer Section -->
            <footer class="footer mt-auto py-3">
                <div class="container">
                    <div class="row">
                        <div class="col-md-7 text-center">
                            <span class="text-muted" style="font-size: 12px;">PPES Consults Sdn Bhd is a wholly-owned subsidiary of Sarawak Economic Development Corporation (SEDC)</span>
                        </div>
                        <div class="col-md-5 text-center">
                            © <span id="currentYear" style="font-size: 12px;"></span> <span style="font-size: 12px;">PPES Consults (PCSB). All Rights Reserved.</span> 
                        </div>
                    </div>
                </div>
            </footer>

            <script>
        $(document).ready(function () {
            $('.js-example-basic-single').select2();
        });

        function updateCompanyDetails() {
            var selectedCompanyID = document.getElementById("selectCompanyID").value;

            // Check if a company ID is selected
            if (selectedCompanyID) {
                // AJAX request to fetch company details
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "check.php", false);  // Set to synchronous for simplicity
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhr.send("checkCompanyID=" + selectedCompanyID);

                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);
                    document.getElementById("outputCompanyName").value = response.OrgName;
                    document.getElementById("outputCompanyEmail").value = response.OrgEmail;
                }
            }
        }

        function checkCompanyDetails() {
            // You can add additional validation here if needed

            // Allow form submission
            return true;
        }
    </script>

    <!-- JavaScript to get the current year -->
    <script>
        document.getElementById("currentYear").innerHTML = new Date().getFullYear();
    </script>   
</body>

</html>
