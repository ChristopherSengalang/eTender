var inputData = {};
var form = $('#post-form');
var auto_loader = $('#auto-saveloader');
var save_loader = $('#saveloader');
var submit_btn = $('#submit-btn');

$(document).ready(function(){
    // Input values
    inputData.title = form.find('#title').val()
    inputData.content = form.find('#content').val()

    function autosave_post(){
        //Check first if changes has been made
        if(inputData.title !== form.find('#title').val() || inputData.content !== form.find('#content').val()){
            // Renew Saved input data
            inputData.title = form.find('#title').val()
            inputData.content = form.find('#content').val() 
            
            // Display Autosaving draft loader
            auto_loader.removeClass('d-none')

            // Disable Submit Button
            submit_btn.attr('disabled', true)

            //Save draft
            $.ajax({
                url:"save_post.php?save_as=draft",
                method:"POST",
                data:form.serialize(),
                dataType:"JSON",
                error: err => {
                    console.error("Saving Post Draft failed.")
                    console.error(err)
                    setTimeout(function(){

                        // Hide Autosaving draft loader
                        auto_loader.addClass('d-none')

                        // Disable Submit Button
                        submit_btn.attr('disabled',false)
                        console.log("Autosave has ended")
                    },500)
                },
                success:function(response){
                    if(!!response.status){
                        if(response.status == "success"){
                            $('[name="id"]').val(response.id)
                            $('[name="auto_id"]').val(response.auto_id)
                            var base_link = location.origin + location.pathname
                            history.pushState("", "", base_link+"?id="+response.id+"&auto_id="+response.auto_id)
                        }else{
                            console.error("Saving Post Draft failed.")
                            console.error(response)
                        }
                    }else{
                        console.error("Saving Post Draft failed.")
                        console.error(response)
                    }

                    setTimeout(function(){

                        // Hide Autosaving draft loader
                        auto_loader.addClass('d-none')

                        // Disable Submit Button
                        submit_btn.attr('disabled',false)
                        console.log("Autosave has ended")
                    },500)

                }
            })

        }
    }

    form.submit(function(e){
        e.preventDefault()
        clearInterval(autosave_interval)

         // Display Autosaving draft loader
         save_loader.removeClass('d-none')

         // Disable Submit Button
         submit_btn.attr('disabled', true)

         //Save draft
         $.ajax({
             url:"save_post.php?save_as=publish",
             method:"POST",
             data:form.serialize(),
             dataType:"JSON",
             error: err => {
                 console.error("Saving Post failed.")
                 console.error(err)
                 autosave_interval;
                 setTimeout(function(){

                     // Hide Saving post loader
                     save_loader.addClass('d-none')

                     // Disable Submit Button
                     submit_btn.attr('disabled',false)
                 },500)
             },
             success:function(response){
                 if(!!response.status){
                     if(response.status == "success"){
                         $('[name="id"]').val(response.id)
                         $('[name="auto_id"]').val(response.auto_id)
                         alert("Post has been published successfully.")
                         location.href = './'
                     }else{
                         console.error("Saving Post failed.")
                         console.error(response)
                     }
                 }else{
                     console.error("Saving Post failed.")
                     console.error(response)
                 }

                 setTimeout(function(){

                     // Hide Autosaving draft loader
                     save_loader.addClass('d-none')

                     // Disable Submit Button
                     submit_btn.attr('disabled',false)
                 },500)
                 autosave_interval;
             }
         })
    })

    var autosave_interval = setInterval(function(){
        console.log("Autosave has started")
        autosave_post()
    }, 3000)


})