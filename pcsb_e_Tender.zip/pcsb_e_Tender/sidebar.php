<?php
 include('config.php');
$conn = null;
?>
        
        <div class="left-sidebar">            
            <div class="scroll-sidebar">                
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>                                                         
                        <li> <a class="#" href="tender" aria-expanded="false"><i class="fa fa-book"></i><span>Tender</span></a>                          
                        </li>
						<li> <a class="#" href="myBiddings" aria-expanded="false"><i class="fa fa-suitcase"></i><span>View Bids</span></a>                            
                        </li>
                        <li> <a class="#" href="confirmBiddings" aria-expanded="false"><i class="fa fa-suitcase"></i><span>Confirmed Bids</span></a>                            
                        </li>
                    </ul>
                </nav>
                
            </div>
            
        </div>
        