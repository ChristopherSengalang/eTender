<?php
session_start();
if (!isset($_SESSION['userId'])) {
    header('location: login.php');
}

if (isset($_GET['TenderID'])) {
    $tenderID = $_GET['TenderID'];

    // Fetch the data of the selected tender from the database
    require 'includes/dbh.inc.php';
    $sql = "SELECT * FROM tender WHERE TenderID = '$tenderID'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    // Display the form for editing
    include "header.php";
    include "sidebar.php";
    include "config.php";
    ?>

    <div class="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title"><b><u>Edit Tender</u></b></h4>
                            <form action="update_tender.php" method="post">
                                <input type="hidden" name="tenderID" value="<?php echo $row['TenderID']; ?>">
                                <!-- Add other fields you want to edit -->
                                <label for="newDueDate">New Due Date:</label>
                                <input type="text" name="newDueDate" value="<?php echo $row['DueDate']; ?>">
                                <br>
                                <input type="submit" value="Update Tender">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    include "footer.php";
} else {
    header('location: dashboard.php'); // Redirect to the dashboard if no TenderID is provided
}
?>
