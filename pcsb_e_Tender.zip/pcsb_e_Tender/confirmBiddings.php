<?php
include"dbconfig.php";

	 $query="SELECT * FROM `bidding` INNER JOIN tender on bidding.tenderid=tender.id WHERE bidding.userid='".$_SESSION['id']."' and bidding.status='1' ";
	$result=select($query);


?>
<?php include"header.php"?>
<?php include"sidebar.php"?>


        
        <div class="page-wrapper">
            
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-bold">PCSB e-Tender Management System</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>            
            <div class="container-fluid">
                  <marquee scrollamount=4><b>WELCOME <?php echo $_SESSION['mobile'] ?>. For general enquiries : Please contact us at <i>Tel: +6082 286 874, Email: pcsb@sedc.com.my</i></b></marquee>         
            </div>
             <div class="container-fluid"> 
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body" style="height:50%">
                                <h4 class="card-title"><b><u>Tender Notice</u></b></h4>
                                <div class="table-responsive m-t-10">
                               <!-- Tender Table -->
                               <?php
                                $n=1;
                                while($r=mysqli_fetch_array($result))
                                {extract($r);
                                ?>
                                <div class="table-responsive m-t-40">
                               <!-- Tender Table -->
                               <div class="table-responsive m-t-40">                            
                                <table id="" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                            <th>BIM Model</th>
                                            <th>Tender Title</th>
                                            <th>Tender No.</th>
                                            <th>Tender ID</th>
                                            <th>Due Date</th>
                                            <th>Tender Documents Download links (Copy & Paste in browser)</th>
                                            <th></th>
                                            <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td><?=$TenderName?></td>
                                            <td><?=$Department?></td>
                                            <td><?=$TenderNo?></td>
                                            <td><?=$r[9]?></td>
                                            
                                            <td><?=$DueDate?></td>
                                            <td><?=$Duration?></td>
                                            <th><a href="submit-form-wpc.php" class="btn btn-success">Upload Documents</a></th>
                                        </tr>
                                        </tbody>
                                    </table>

                                    </div>
                                </div>
                            </div>
                            <?php
                            $n++;
                            }
                            ?>
                        <!-- End Table --> 

                                </div>
                            </div>
                        </div>
                    </div>     
                </div>
                           
            </div>
                <footer class="footer text-center" ><strong><mark>© 2024, PPES Consults (PCSB). All Rights Reserved.     </mark></strong>
             

<?php include"footer.php"?>
           