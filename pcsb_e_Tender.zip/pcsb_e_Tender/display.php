<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Files</title>
</head>
<body>

    <?php
    // Connect to the database
    $pdo = new PDO('mysql:host=localhost;dbname=your_database', 'root', '');

    // Fetch file names from the database
    $stmt = $pdo->query("SELECT file_name FROM combined_files");
    $fileNames = $stmt->fetchAll(PDO::FETCH_COLUMN);
    ?>

    <label for="fileNamesTextbox">File Names:</label>
    <textarea id="fileNamesTextbox" rows="10" cols="50"><?php echo implode("\n", $fileNames); ?></textarea>

</body>
</html>