<?php
include"dbconfig.php";

	 $query="select * from tender";
	$result=select($query);


?>
<?php include"header.php"?>
<?php include"sidebar.php"?>


        
        <div class="page-wrapper">
            
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-bold">PCSB e-Tender Management System</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>            
            <div class="container-fluid">
                  <marquee scrollamount=4><b>WELCOME <?php echo $_SESSION['mobile'] ?>. For general enquiries : Please contact us at <i>Tel: +6082 286 874, Email: pcsb@sedc.com.my</i></b></marquee>         
            </div>
             <div class="container-fluid"> 
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body" style="height:50%">
                                <h4 class="card-title"><b><u>Tender Notice</u></b></h4>
                                <div class="table-responsive m-t-10">
                               <!-- Tender Table -->
                               <?php
                                $n=1;
                                while($r=mysqli_fetch_array($result))
                                {extract($r);
                                ?>
                                <div class="table-responsive m-t-40">
                               <!-- Tender Table -->
                               <div class="table-responsive m-t-40">                            
                                <table id="" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                            <th>Tender No.</th>
                                            <th>Title</th>
                                            <th>Tender Briefing</th>
                                            <th>Collection of Tender Document</th>
                                            <th>Closing Date of Tender Submission</th>
                                            <th>-</th> 

                                            </tr>
                                        </thead>
                                        <tbody>

                                        <!-- Calling Tender Database -->
                                    <tr>
                                        <td><?=$TenderNo?></td>
                                        <td><?=$Department?></td>
                                        <td><?=$Description?></td>
                                        <td><?=$Price?></td>
                                        <td><?=$DueDate?></td>
                                        <td class="center">
                                        <a href="biddings?id=<?=$id?>&qty1=<?=$qty?>&inr=<?=$INR?>""><div class="col-lg-1"><button class="btn btn-primary ">B I D</button></div></a>
                                        </td>
                                    </tr>

                                        </tbody>
                                    </table>

                                    </div>
                                </div>
                            </div>
                            <?php
                            $n++;
                            }
                            ?>
                            <!-- End Table --> 
                                </div>
                            </div>
                        </div>
                    </div>     
                </div>
                           
            </div>
                <footer class="footer text-center" ><strong><mark>© 2024, PPES Consults (PCSB). All Rights Reserved.     </mark></strong>
             

<?php include"footer.php"?>
           