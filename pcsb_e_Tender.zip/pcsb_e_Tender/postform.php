<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Form | Autosave draft - PHP, jQuery, and Ajax</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js" integrity="sha512-naukR7I+Nk6gp7p5TMA4ycgfxaZBJ7MO5iC3Fp6ySQyKFHOGfpkSZkYVWV5R7u7cfAicxanwYQ5D1e17EfJcMA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <style>
        html, body{
            min-height:100%;
            width:100%;
        }
    </style>
</head>
<body>
    <?php 
    require_once('db-connect.php');
    if(isset($_GET['auto_id']) || isset($_GET['id'])){
        $_id = isset($_GET['auto_id']) ? $_GET['auto_id'] : (isset($_GET['id']) ? $_GET['id'] : "");
        if(!empty($_id)){
            $sql = "SELECT * FROM `posts` where `id` = '{$_id}'";
            $get = $conn->query($sql);
            if($get->num_rows > 0){
                $result = $get->fetch_assoc();
                $id = $result['id'];
                $title = stripslashes($result['title']);
                $content = stripslashes($result['content']);
                $status = $result['status'];
                if($result['status'] == 'draft'){
                    $id = $result['parent_id'] > 0 ? $result['parent_id'] : "";
                    $auto_id = $result['id'] > 0 ? $result['id'] : "";
                }
            }
        }
    }
    if(isset($id) && !isset($auto_id) && isset($status) && $status == 'publish'){
        $check_draft_sql = "SELECT id FROM `posts` where `status` = 'draft' and `parent_id` = '{$id}' order by abs(unix_timestamp(`created_at`)) desc limit 1";
        $check_draft = $conn->query($check_draft_sql);
        if($check_draft->num_rows > 0){
            $draft_available_id = $check_draft->fetch_assoc()['id'];
        }
    }
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary bg-gradient">
        <div class="container">
            <a class="navbar-brand" href="./">Autosave Draft</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                    <a class="nav-link" href="./">Home</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="postform.php"><i class="fa fa-plus"></i>Create Post</a>
                    </li>
                   
                </ul>
            </div>
            <div>
                <a href="https://sourcecodester.com" class="text-light fw-bolder h6 text-decoration-none" target="_blank">SourceCodester</a>
            </div>
        </div>
    </nav>
    <div class="container-fluid px-5 my-3" >
        <div class="col-lg-8 col-md-10 col-sm-12 mx-auto">
            <h3 class="text-center"><b>Post Form</b></h3>
            <div class="d-flex w-100 justify-content-center">
                <hr class="w-50">
            </div>
            <div class="card rounded-0 shadow mb-3">
                <div class="card-header rounded-0">
                    <div class="card-title"><b><?= isset($_GET['id']) ? "Edit Post" : "Create New Post" ?></b></div>
                </div>
                <div class="card-body">
                    <div class="container-fluid">
                        <form action="" id="post-form">
                            <input type="hidden" name="id" value="<?= isset($id) ? $id : 0  ?>">
                            <input type="hidden" name="auto_id" value="<?= isset($auto_id) ? $auto_id : "" ?>">

                            <?php if(isset($draft_available_id)): ?>
                                <div class="alert alert-warning rounded-0">
                                    Draft Detected from Autosave of this post. <a href="./postform.php?id=<?= $id ?>&auto_id=<?= $draft_available_id ?>">Load Draft</a>
                                </div>
                            <?php endif; ?>
                            <div class="mb-3">
                                <label for="title" class="form-label">Title</label>
                                <input type="text" class="form-control" name="title" id="title" value="<?= isset($title) ? $title : ""  ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="content" class="form-label">Content</label>
                                <textarea name="content" id="content" class="form-control" rows="10"><?= isset($content) ? $content : "" ?></textarea>
                            </div>
                            <div class="mb-3 d-none" id="auto-saveloader">
                                <div class="d-flex w-100 align-items-center">
                                    <div class="spinner-border spinner-border-sm" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <div class="col-auto px-4">
                                        Saving Draft
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3 d-none" id="saveloader">
                                <div class="d-flex w-100 align-items-center">
                                    <div class="spinner-border spinner-border-sm" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <div class="col-auto px-4">
                                        Publishing Post
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3 text-center">
                                <button id="submit-btn" class="btn btn-primary rounded-pill col-lg-3 col-md-4 col-sm-6">Publish</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="postform.js"></script>
</body>
</html>