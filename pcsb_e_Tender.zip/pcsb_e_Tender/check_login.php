<?php
session_start();
 if((isset($_SESSION["companyEmail"]) && isset($_SESSION["password"])) ) {

$companyEmail = $_SESSION['companyEmail'];


}else{

header("location:login.php");

}

?>