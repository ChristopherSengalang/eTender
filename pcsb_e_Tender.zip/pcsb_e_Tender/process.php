<?php
if (isset($_POST['submit'])) {
    $files = $_FILES['files']['tmp_name'];

    // Create a unique zip file
    $zipFilename = 'WPC0xx' . time() . '.zip';
    $zip = new ZipArchive();

    if ($zip->open($zipFilename, ZipArchive::CREATE) === TRUE) {
        foreach ($files as $index => $tmpFile) {
            $filename = $_FILES['files']['name'][$index];
            $zip->addFile($tmpFile, $filename);
        }
        $zip->close();

        // Save to database
        $pdo = new PDO('mysql:host=localhost;dbname=tms', 'root', '');
        $content = file_get_contents($zipFilename);

        $stmt = $pdo->prepare("INSERT INTO bids (file_name, file_content) VALUES (?, ?)");
        $stmt->bindParam(1, $zipFilename);
        $stmt->bindParam(2, $content, PDO::PARAM_LOB);
        $stmt->execute();



        if (!$stmt) {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        } else {
            echo "<script type='text/javascript'>alert('TENDER GENERATED SUCCESSFULLY!!');
            window.location.href='tender';
            </script>";
        }
    } else {
        header('location: confirmBiddings');
        exit();
    }
}
?>
