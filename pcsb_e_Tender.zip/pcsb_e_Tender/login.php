<?php
include"dbconfig.php";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">

    <style>
        body {
    margin: 0;
    padding: 0;
    height: 100%;
    background: none;
}

.background-image {
    background-image: url('https://wallpapercave.com/wp/wp9651373.jpg'); /* Replace 'engineering_background.jpg' with your image file */
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.bg-primary {
    background: none;
}
.footer {
    background-color: #f8f9fa;
}

    </style>
</head>

<body class="bg-primary">
    <div class="background-image">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-8 col-sm-10">
                    <div class="card o-hidden border-0 shadow-lg my-5">
                        <div class="card-body p-0">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="p-5">
                                        <!-- Logo Section -->
                                        <div class="text-center">
                                            <img src="./adminlte/img/logo2.png" style="width: 100px;height: 100px;" alt="Your Company Logo" class="img-fluid mb-4">
                                            <h1 class="h4 text-gray-900 mb-4">LOGIN</h1>
                                        </div>
                                        <!-- End Logo Section -->
                                        <form class="user"  method="post">
                                            <div class="form-group">
                                                <input type="text" class="form-control form-control-user"
                                                    placeholder="company Email" name="email" required>
                                            </div>
                                            <div class="form-group">
                                                <input type="password" class="form-control form-control-user"
                                                    placeholder="Password"  name="password" required>
                                            </div>
                                            <button type="submit"
                                                class="btn btn-primary btn-user btn-block" value="Login" name="login">Login</button>
                                        </form>
                                        <hr>
                                        <div class="text-center">
                                            <a class="small" href="register">Create an Account!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

            <!-- Footer Section -->
            <footer class="footer mt-auto py-3">
                <div class="container">
                    <div class="row">
                        <div class="col-md-7 text-center">
                            <span class="text-muted" style="font-size: 12px;">PPES Consults Sdn Bhd is a wholly-owned subsidiary of Sarawak Economic Development Corporation (SEDC)</span>
                        </div>
                        <div class="col-md-5 text-center">
                            © <span id="currentYear" style="font-size: 12px;"></span> <span style="font-size: 12px;">PPES Consults (PCSB). All Rights Reserved.</span> 
                        </div>
                    </div>
                </div>
            </footer>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script>
        document.getElementById("currentYear").innerHTML = new Date().getFullYear();
    </script>
    				  <?php
if(isset($_REQUEST['login']))
	{
		
	$email=trim($_REQUEST['email']);
	$password=trim($_REQUEST['password']);
	
	
	$query="select * from registration where email='$email' and password='$password' and isadmin=0";
	
	
	
	$login_data=select($query);
	$n=mysqli_num_rows($login_data);
	if($n==1)
	{
		while($data=mysqli_fetch_array($login_data))
		{
		extract($data);
		//print_r($data);
		}
		
		$_SESSION['name']=$name;
		$_SESSION['mobile']=$mobile;
		$_SESSION['email']=$email;
		$_SESSION['isadmin']=$isadmin;
		$_SESSION['id']=$id;
		$_SESSION['login']="yes";
	//print_r($_SESSION);	
		 echo'<script>alert("login success");
window.location="tender"		 </script>';
	}
	else
	{
		echo"email or password is incorrect";
	}
	}
		
	
			  
			  
			  ?>
</body>

</html>
