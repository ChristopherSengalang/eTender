<?php
session_start();
if (!isset($_SESSION['userId'])) {
    header('location: login.php');
}
?>
<?php include"header.php"?>
<?php include"sidebar.php"?>
<?php include"config.php"?>

        
        <div class="page-wrapper">
            
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-bold">PCSB e-Tender Management System</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>            
            <div class="container-fluid">
                  <marquee scrollamount=4><b>WELCOME <?php echo $_SESSION['userUid'] ?>. For General Enquiries : Please contact us at <i>Tel: +6082 286 874, Email: pcsb@sedc.com.my</i></b></marquee>         
            </div>
             <div class="container-fluid"> 
                <div class="row card-box">
                    <div class="col-md-12">

                    </div>
                    <div class="col-md-12">
  
                    </div>
                    <div class="col-md-12">

                    </div>
                </div>
                </div>                             
            </div>
                <footer class="footer text-center" ><strong><mark>© 2024, PPES Consults (PCSB). All Rights Reserved.     </mark></strong>
             

<?php include"footer.php"?>
           